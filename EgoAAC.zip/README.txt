##########################################
# Thank you for purchasing EgoAACConfig V1.0     Made By: Makinzi/alexchoi0320                                                         
# This config currently only works with 1.8
# 1.9/1.10/1.11 support will be added soon.


Changelog:

V1.0
* Fixed Killaura Values

-Makinzi
